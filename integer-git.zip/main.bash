#!/bin/bash
echo "enter a integer"
read m
a=1
echo "n natural numbers:"
for((a=1;a<=m;a++))
do
echo $a
done
