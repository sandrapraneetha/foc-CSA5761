#!/bin/sh
echo "enter a number"
read a
cube=$((a*a*a))
echo "cube of "$a"="$cube

