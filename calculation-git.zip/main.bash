#!/bin/bash
echo "enter a number:"
read a
echo "enter a number:"
read b
sum=$((a+b))
echo "sum ="$sum
subtraction=$((a-b))
echo "subtraction="$subtraction
mult=$((a*b))
echo "product="$mult
div=$((a/b))
echo "division="$div

