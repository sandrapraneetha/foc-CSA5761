#!bin/sh
echo "enter a number"
read a
square=$((a*a))
echo "square of "$a"="$square